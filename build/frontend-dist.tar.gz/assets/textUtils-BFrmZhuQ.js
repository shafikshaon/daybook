const a=t=>t?t.split("_").map(r=>r.charAt(0).toUpperCase()+r.slice(1).toLowerCase()).join(" "):"";export{a as f};
